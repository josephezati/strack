from django.apps import AppConfig


class WebsiteHomeConfig(AppConfig):
    name = 'website_home'
