from django.apps import AppConfig


class DeoConfig(AppConfig):
    name = 'deo'
